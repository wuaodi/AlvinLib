"""
根据result_bbox.csv 与 confidence/preds.csv 生成用于精度评定的txt文档
"""

import pandas as pd

df1 = pd.read_csv("result_bbox.csv")
df2 = pd.read_csv("confidence/preds.csv")

df3 = pd.merge(df1, df2, left_on="File_name", right_on="id")    # 左连接
df3.insert(df3.shape[1], 'class', 0)    # 添加全零列

df3.to_csv("df3.csv")

df4 = df3.groupby(by=["File_name"])
df4 = list(df4)

for i in range(len(df4)):
    name = str(df4[i][1].iloc[0, 1])[0:-4]
    print(name)
    df4[i][1].to_csv("result_txt/" + name + ".txt", columns=["class", "target", "bbox_x1", "bbox_y1", "bbox_x2", "bbox_y2"],
                     index=0, header=0, sep=' ', float_format='%.6f')

"""
根据mask生成bbox标签
有两个阈值可以调整00

一个是二值化的阈值percent, 二值化阈值设置成输入图像最大亮度的20%

一个是生成bbox时连续区域大小的阈值area_thr, 设置为100
"""


import numpy as np
from skimage.measure import label,regionprops
import os
import cv2
import pandas as pd


def get_patch_csv(filename_list, root_dir, output_path, area_thr=100, percent=0.2):
    # take the pred mask of segmention
    annotation = pd.DataFrame()
    name_list = []
    x1_list = []
    y1_list = []
    x2_list = []
    y2_list = []
    bbox_id_list = []
    bounding_boxes_list = []
    for filename in filename_list:
        im_path = os.path.join(root_dir, filename)
        print(im_path)
        img = cv2.imread(im_path, 0)

        # if len(img.shape)>2:
        #     img = img[:, :, 0]

        # 二值化
        threshold = np.max(img) * percent
        ret, img = cv2.threshold(img, threshold, 255, cv2.THRESH_BINARY)

        # cv2.imshow('0 and 255', img)
        # cv2.waitKey(0)

        label_img = label(img)
        bbox_id = 0
        for r in regionprops(label_img):
            if r.area < area_thr:
                continue
            name_list.append(filename[0:-3] + 'jpg')
            bbox_id_list.append(bbox_id)
            bbox_id += 1
            x1_list.append(r.bbox[1])
            y1_list.append(r.bbox[0])
            x2_list.append(r.bbox[3])
            y2_list.append(r.bbox[2])
            bounding_boxes_list.append(','.join([str(r.bbox[i]) for i in [1, 0, 3, 2]]))
    annotation['File_name'] = name_list
    annotation['bbox_id'] = bbox_id_list
    annotation['bbox_x1'] = x1_list
    annotation['bbox_y1'] = y1_list
    annotation['bbox_x2'] = x2_list
    annotation['bbox_y2'] = y2_list
    annotation['Bounding_boxes'] = bounding_boxes_list
    annotation.to_csv(output_path)


if __name__ == "__main__":
    root_dir = 'result_mask'
    output_path = 'result_bbox.csv'
    filename_list = os.listdir(root_dir)
    get_patch_csv(filename_list, root_dir, output_path, area_thr=2500, percent=0.4)

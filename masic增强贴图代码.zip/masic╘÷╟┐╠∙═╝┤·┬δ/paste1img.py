"""
程序功能：
以背景文件夹中的图片（大小为448*448）为底图、
从前景文件夹中随机选一张图，resize到224*224，随机贴到背景图上
结果保存在存结果文件夹
"""

import os
import cv2
import random


def get_fore_name(dir_path):
    fore_names = os.listdir(dir_path)
    index = random.randint(0, len(fore_names) - 1)

    return fore_names[index]


def paste(back_img_path, fore_img_path):
    back_img = cv2.imread(back_img_path)
    fore_img = cv2.imread(fore_img_path)

    img_shape = random.randint(100, 400)    # 前景随机大小100到400之间，背景为448*448

    fore_img = cv2.resize(fore_img, (img_shape, img_shape))

    x = random.randint(0, 448 - img_shape)  # 粘贴图像的左上角横坐标
    y = random.randint(0, 448 - img_shape)  # 粘贴图像的左上角纵坐标

    back_img[x:x + img_shape, y:y + img_shape] = fore_img

    return back_img


if __name__ == "__main__":
    background_dir_path = 'intermediate_result/'  # 背景文件夹路径
    foreground_dir_path = 'raw_dataset_v2/none/'  # 前景文件夹路径
    result_path = 'result_none_randomSize/'  # 存结果文件夹路径

    for back_name in os.listdir(background_dir_path):
        back_path = background_dir_path + back_name    # 获得待处理的背景图像路径
        fore_path = foreground_dir_path + get_fore_name(foreground_dir_path)  # 获得一张随机挑选的前景图像的路径
        result_img = paste(back_path, fore_path)  # 得到粘贴后的图像
        print(result_path+back_path)
        cv2.imwrite(result_path+back_name, result_img)    # 保存结果

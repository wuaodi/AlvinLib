import os
import cv2

dir_path = 'raw_dataset_v2/none/'

for img in os.listdir(dir_path):
    print(img)
    img = cv2.imread(dir_path + img)
    img = cv2.resize(img,(224,224))